# Nocturne Atelier

Single-route static site inspired by the supplied scroll-film reference: dark atelier photography, kinetic typography, and a scroll-driven mechanism study.

## Deploy on Ubuntu

Copy the complete `prod.tar.gz` archive to the server, extract it into a dedicated directory, then run:

    chmod +x deploy.sh
    ./deploy.sh

The site will be available at `http://127.0.0.1:8080` on the server. To bind a different local port:

    PORT=8090 ./deploy.sh

The image is static-only and contains no secrets, runtime environment variables, external trackers, or outbound application calls. Nginx runs as an unprivileged user with a read-only filesystem, dropped Linux capabilities, and restrictive security headers.

## Stop / inspect

    docker compose ps
    docker compose logs --tail=100 web
    docker compose down

For a quick non-container preview during development:

    python3 -m http.server 8080 --directory dist
