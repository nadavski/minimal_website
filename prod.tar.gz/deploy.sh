#!/usr/bin/env bash
set -Eeuo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")"

command -v docker >/dev/null 2>&1 || { echo "Docker is required." >&2; exit 1; }
docker compose version >/dev/null 2>&1 || { echo "Docker Compose v2 is required." >&2; exit 1; }

port="${PORT:-8080}"
if ! [[ "$port" =~ ^[0-9]+$ ]] || (( port < 1024 || port > 65535 )); then
  echo "PORT must be a number between 1024 and 65535." >&2
  exit 1
fi

docker compose config --quiet
docker compose up -d --build --remove-orphans

for attempt in {1..30}; do
  if curl --fail --silent --show-error "http://127.0.0.1:${port}/healthz" | grep -qx ok; then
    echo "Nocturne Atelier is live at http://127.0.0.1:${port}"
    exit 0
  fi
  sleep 1
done

echo "The container did not become healthy. Recent status:" >&2
docker compose ps >&2
exit 1
